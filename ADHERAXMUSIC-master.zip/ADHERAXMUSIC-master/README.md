━━━━━━━━━━━━━━━━━━━━
### 🌷𝐕𝐈𝐒𝐈𝐓𝐎𝐑𝐒🌷

<!--
**THE-VIP-BOY-OP/THE-VIP-BOY-OP** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.


<p align="center">
    <b>ᴠɪsɪᴛᴏʀs</b><br>
 -->    <img align="middle" src="https://profile-counter.glitch.me/THE-VIP-BOY-OP/count.svg" />
</p>




<h2 align="center">
    ──「 🅐︎🅓︎🅗︎🅔︎🅡︎🅐︎ 🅜︎🅤︎🅢︎🅘︎🅒︎」──



★ 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 𝙷𝙴𝚁𝙾𝙺𝚄 + 𝚅𝙿𝚂 ★
</h2>

<p align="center">
  <img src="https://graph.org/file/83ac51a71d02c89646d0f.jpg">
</p>

**𝙏𝙀𝙎𝙏 𝘽𝙊𝙏 ➣ [𝄟ॐ❥🅐︎🅓︎🅗︎🅔︎🅡︎🅐︎🅧︎🅜︎🅤︎🅢︎🅘︎🅒︎❥𝄟⃟🥀](https://t.me/II_VIP_MUSIC_II_BOT)**



<h2 align="center">
    ⚠️「 📍𝗙𝗢𝗥𝗞 𝗧𝗛𝗜𝗦 𝗥𝗘𝗣𝗢 𝗙𝗜𝗥𝗦𝗧𝗟𝗬📍 」⚠️

<P align="center">
   <img src="https://graph.org/file/6fff6a80e7b9aa16e54ab.jpg">
</p>


<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─

<h3> 𝗛𝗘𝗥𝗢𝗞𝗨 𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗕𝗨𝗧𝗧𝗢𝗡 </h3>
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/FIDAAXRAJ/ADHERAXMUSIC"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-bringle?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

<h2 align="center">

🚩「 🅘︎🅕︎ 🅐︎🅝︎🅨︎ 🅔︎🅡︎🅡︎🅞︎🅡︎ 🅘︎🅝︎ 🅑︎🅞︎🅣︎ 🅓︎🅜︎ 🅜︎🅔︎  」🚩
<p align="center">
<a href="https://telegram.me/ll_ADHERA_KING_ll"><img src="https://img.shields.io/badge/-☆ᴅᴍ ᴛᴏ ᴀᴅʜᴇʀᴀ%20☆-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>
<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʟᴏᴄᴀʟ ʜᴏsᴛ/ ᴠᴘs 」─
</h3>

- Get your [Necessary Variables](https://github.com/THE-VIP-BOY-OP/VIP-MUSIC/blob/master/sample.env)
- Upgrade and Update by :
`sudo apt-get update && sudo apt-get upgrade -y`
- Install Ffmpeg by :
`sudo apt-get install python3-pip ffmpeg -y`
- Install required packages by :
`sudo apt-get install python3-pip -y`
- Install pip by :
`sudo pip3 install -U pip`
- Install Node js by :
`curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm`
- Clone the repository by :
`git clone https://github.com/THE-VIP-BOY-OP/VIP-MUSIC && cd VIP-MUSIC`
- Install requirements by :
`pip3 install -U -r requirements.txt`
- Fill your variables in the env by :
`vi sample.env`<br>
Press `I` on the keyboard for editing env<br>
Press `Ctrl+C` when you're done with editing env and `:wq` to save the env<br>
- Rename the env file by :
`mv sample.env .env`
- Install tmux to keep running your bot when you close the terminal by :
`sudo apt install tmux && tmux`
- Finally run the bot by :
`bash start`
- For getting out from tmux session : Press `Ctrl+b` and then `d`<br>
━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/TG_FRIENDSS"><img src="https://img.shields.io/badge/-Support%20Group-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<p align="center">
<a href="https://telegram.me/VIP_CREATORS"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

